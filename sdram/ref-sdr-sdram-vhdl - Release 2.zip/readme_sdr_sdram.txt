SDR SDRAM Controller v1.1 readme.txt

This readme file for the SDR SDRAM Controller includes information that was not
incorporated into the SDR SDRAM Controller White Paper v1.1.

The PLL is targeted at APEX(TM) devices. Please regenerate for your chosen architecture.


Last updated September, 2002
Copyright � 2002 Altera Corporation. All rights reserved.


